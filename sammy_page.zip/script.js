function openCard(){
  document.getElementById('card').classList.remove('hidden');
}